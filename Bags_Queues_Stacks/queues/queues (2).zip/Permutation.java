/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.StdOut;

public class Permutation {
    public void Permutation() {
        //empty constructor
    }

    public static void main(String[] args) {
        if (args.length == 1) throw new IllegalArgumentException("Require number of outpus k, "
                                                                         + "and the input string");

        RandomizedQueue<String> model = new RandomizedQueue<String>();

        int k = Integer.parseInt(args[0]);

        // Read input
        for (int n = 1; n < args.length; n++) {
            model.enqueue(args[n]);
        }

        // Print k outpus
        for (int i = 0; i < k; i++) {
            StdOut.println(model.dequeue());
        }

    }
}
